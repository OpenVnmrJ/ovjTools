/* This file is for use with compilers that don't have the capability to
 * #define symbols on the C compiler command line.  This file must
 * be #include'd before all other ck*.h files so that the symbols #define'd
 * here can be used for any subsequent conditional code.
 */
